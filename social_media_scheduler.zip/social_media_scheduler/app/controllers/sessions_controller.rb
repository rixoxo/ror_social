class SessionsController < ApplicationController
    def new
      # No need to explicitly render; Rails will look for sessions/new.html.erb
    end
  end
  