class HomeController < ApplicationController
  def index
    # This will render app/views/home/index.html.erb
  end

  def home
    # This will render app/views/home/home.html.erb
  end

  def login
    # This will render app/views/home/login.html.erb
  end
end
